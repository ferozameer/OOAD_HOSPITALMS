﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace DBMS_PROJECT_HMS
{
    public partial class receptionist : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Admin\Documents\HMS.mdf;Integrated Security=True;Connect Timeout=30");
        public receptionist()
        {
            InitializeComponent();
        }
        void populate()
        {
            con.Open();
            string query = "select * from ReceptionistTable";
            SqlDataAdapter da = new SqlDataAdapter(query, con);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            RECEPDGV.DataSource = ds.Tables[0];
            con.Close();
        }
        private void button3_Click(object sender, EventArgs e)
        {
            if (Rid.Text == "" || Rname.Text == "" || Rpass.Text == "" || Rphone.Text == "" || Raddress.Text == "")
                MessageBox.Show("Please Fill The Empty Fields!");
            else
            {
                con.Open();
                string query = "insert into ReceptionistTable values("+ Rid.Text + ",'" + Rname.Text + "','"+ Rpass.Text + "','" + Rphone.Text + "','" + Raddress.Text + "')";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Receptionist Successfully Added!");
                con.Close();
                populate();
            }
        }

        private void receptionist_Load(object sender, EventArgs e)
        {
            populate();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (Rid.Text == "")
                MessageBox.Show("Enter The Receptionist Id!");
            else
            {   con.Open();
                string query = "delete from ReceptionistTable where ReceptionistId="+Rid.Text+"";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Receptionist Successfully Deleted!");
                con.Close();
                populate();

            }
        }
        private void button6_Click(object sender, EventArgs e)
        {
            if (Rid.Text == "" || Rname.Text == "" || Rpass.Text == "" || Rphone.Text == "" || Raddress.Text == "")
            { MessageBox.Show("Incomplete Information!"); }
            else
            {
                con.Open();
                string query = " update ReceptionistTable set ReceptionistName = '" + Rname.Text + "',Password = '" + Rpass.Text + "',Phone = '" + Rphone.Text + "',address='" + Raddress.Text + "' where ReceptionistId = " + Rid.Text + "";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Receptionist Updated Successfully!");
                con.Close();
                populate();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            patients f = new patients();
            f.Show();
            this.Hide();

        }

        private void label10_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void RECEPDGV_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            Rid.Text = RECEPDGV.Rows[e.RowIndex].Cells[0].Value.ToString();
            Rname.Text = RECEPDGV.Rows[e.RowIndex].Cells[1].Value.ToString();
            Rpass.Text = RECEPDGV.Rows[e.RowIndex].Cells[2].Value.ToString();
            Rphone.Text = RECEPDGV.Rows[e.RowIndex].Cells[3].Value.ToString();
            Raddress.Text = RECEPDGV.Rows[e.RowIndex].Cells[4].Value.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Doctors d = new Doctors();
            d.Show();
            this.Hide();
        }


        private void button4_Click(object sender, EventArgs e)
        {
            treatments t = new treatments();
            t.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.Show();
            this.Hide();
        }
    }
    
    }
