﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace DBMS_PROJECT_HMS
{
    public partial class treatments : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Admin\Documents\HMS.mdf;Integrated Security=True;Connect Timeout=30");
        public treatments()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (tid.Text == "" || tdes.Text == "" || tcost.Text == "")
                MessageBox.Show("Please Fill The Empty Fields!");
            else
            {
                con.Open();
                string query = "insert into TreatmentTable values(" + tid.Text + ",'" + tdes.Text + "','" + tcost.Text + "')";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Treatment Successfully Added!");
                con.Close();
                populate();
            }

        }
        void populate()
        {
            con.Open();
            string query = "select * from TreatmentTable";
            SqlDataAdapter da = new SqlDataAdapter(query, con);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            var ds = new DataSet();
            _ = da.Fill(ds);
            treatdgv.DataSource = ds.Tables[0];
            con.Close();
        }

        private void treatments_Load(object sender, EventArgs e)
        {
            populate();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (tid.Text == "")
                MessageBox.Show("Enter The Treatment Id!");
            else
            {
                con.Open();
                string query = "delete from TreatmentTable where TreatmentId=" + tid.Text + "";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Treatment Successfully Deleted!");
                con.Close();
                populate();

            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (tid.Text == "" || tdes.Text == "" || tcost.Text == "" )
            { MessageBox.Show("Incomplete Information!"); }
            else
            {
                con.Open();
                string query = " update TreatmentTable set Description = '" + tdes.Text + "',TreatmentCost = " + tcost.Text + " where TreatmentId = " + tid.Text + "";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Treatment Updated Successfully!");
                con.Close();
                populate();
            }

        }
        private void label8_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void treatdgv_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            tid.Text = treatdgv.Rows[e.RowIndex].Cells[0].Value.ToString();
            tdes.Text = treatdgv.Rows[e.RowIndex].Cells[1].Value.ToString();
            tcost.Text = treatdgv.Rows[e.RowIndex].Cells[2].Value.ToString();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Doctors d = new Doctors();
            d.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            receptionist r = new receptionist();
            r.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            patients p = new patients();
            p.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.Show();
            this.Hide();
        }
    }
}
