﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace DBMS_PROJECT_HMS
{
    public partial class patients : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Admin\Documents\HMS.mdf;Integrated Security=True;Connect Timeout=30");
        public patients()
        {
            InitializeComponent();
        }

        private void patients_Load(object sender, EventArgs e)
        {
            populate();
        }
        void populate()
        {
            con.Open();
            string query = "select * from PatientTable";
            SqlDataAdapter da = new SqlDataAdapter(query, con);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            patdgv.DataSource = ds.Tables[0];
            con.Close();
        }
        private void button3_Click(object sender, EventArgs e)
        {
            if (pid.Text == "" || pname.Text == "" || page.Text == "" || pgen.Text == "" || pblood.Text == "" || pdis.Text == "")
                MessageBox.Show("Please Fill The Empty Fields!");
            else
            {
                con.Open();
                string query = "insert into PatientTable values(" + pid.Text + ",'" + pname.Text + "','" + page.Text + "','" + pgen.Text + "','" + pblood.Text + "','" + pdis.Text + "')";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Patient Successfully Added!");
                con.Close();
                populate();
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (pid.Text == "")
                MessageBox.Show("Enter The Patient Id!");
            else
            {
                con.Open();
                string query = "delete from PatientTable where PatientId=" + pid.Text + "";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Patient Successfully Deleted!");
                con.Close();
                populate();

            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (pid.Text == "" || pname.Text == "" || page.Text == "" || pgen.Text == "" || pblood.Text == "" || pdis.Text == "")
            { MessageBox.Show("Incomplete Information!"); }
            else
            {
                con.Open();
                string query = " update PatientTable set PatientName = '" + pname.Text + "',PatientAge = '" + page.Text + "',Gender = '" + pgen.Text + "',BloodGroup='" + pblood.Text + "',MajorDisease='" + pdis.Text + "' where PatientId = " + pid.Text + "";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Patient Updated Successfully!");
                con.Close();
                populate();
            }
        }

        private void label12_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void patdgv_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {

            pid.Text = patdgv.Rows[e.RowIndex].Cells[0].Value.ToString();
            pname.Text = patdgv.Rows[e.RowIndex].Cells[1].Value.ToString();
            page.Text = patdgv.Rows[e.RowIndex].Cells[2].Value.ToString();
            pgen.Text = patdgv.Rows[e.RowIndex].Cells[3].Value.ToString();
            pblood.Text = patdgv.Rows[e.RowIndex].Cells[4].Value.ToString();
            pdis.Text = patdgv.Rows[e.RowIndex].Cells[5].Value.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Doctors d = new Doctors();
            d.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            receptionist r = new receptionist();
            r.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            treatments t = new treatments();
            t.Show();
            this.Hide();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.Show();
            this.Hide();
        }
    }
}
