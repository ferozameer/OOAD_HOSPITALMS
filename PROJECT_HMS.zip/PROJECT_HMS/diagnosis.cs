﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace DBMS_PROJECT_HMS
{
    public partial class diagnosis : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Admin\Documents\HMS.mdf;Integrated Security=True;Connect Timeout=30");
        public diagnosis()
        {
            InitializeComponent();
        }
        private void fillpatient()
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select PatientId from PatientTable", con);
            SqlDataReader rdr;
            rdr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("PatientId", typeof(int));
            dt.Load(rdr);
            diagpatid.ValueMember = "PatientId";
            diagpatid.DataSource = dt;
            con.Close();
        }
        private void fillTreatment()
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select Description from TreatmentTable", con);
            SqlDataReader rdr;
            rdr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("Description", typeof(string));
            dt.Load(rdr);
            treatid.ValueMember = "Description";
            treatid.DataSource = dt;
            con.Close();
        }
        private void label8_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void diagnosis_Load(object sender, EventArgs e)
        {
            fillpatient();
            fillTreatment();
            populate();

        }
        void populate()
        {
            con.Open();
            string query = "select * from DiagnosisTable";
            SqlDataAdapter da = new SqlDataAdapter(query, con);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            diagdgv.DataSource = ds.Tables[0];
            con.Close();
        }


        private void diagdgv_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            diagid.Text = diagdgv.Rows[e.RowIndex].Cells[0].Value.ToString();
            diagpatid.Text = diagdgv.Rows[e.RowIndex].Cells[1].Value.ToString();
            diagpatname.Text = diagdgv.Rows[e.RowIndex].Cells[2].Value.ToString();
            diagsymp.Text = diagdgv.Rows[e.RowIndex].Cells[3].Value.ToString();
            diagmed.Text = diagdgv.Rows[e.RowIndex].Cells[4].Value.ToString();
            diadiag.Text = diagdgv.Rows[e.RowIndex].Cells[5].Value.ToString();
            treatid.Text = diagdgv.Rows[e.RowIndex].Cells[6].Value.ToString();
            diagcost.Text = diagdgv.Rows[e.RowIndex].Cells[7].Value.ToString();
        }
        string pName;
        private void fetchpnm()
        {

            con.Open();

            string query = "select * from PatientTable where PatientId=" + diagpatid.SelectedValue.ToString() + "";
            SqlCommand cmd = new SqlCommand(query, con);
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                pName = dr["PatientName"].ToString();
                diagpatname.Text = pName;

            }
            con.Close();

        }
        string cost;
        private void fetchtc()
        {

            con.Open();

            string query = "select * from TreatmentTable where Description='" + treatid.SelectedValue + "'";
            SqlCommand cmd = new SqlCommand(query, con);
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                cost = dr["TreatmentCost"].ToString();
                diagcost.Text = cost;

            }
            con.Close();

        }

        private void diagpatid_SelectionChangeCommitted(object sender, EventArgs e)
        {
            fetchpnm();

        }

        private void treatid_SelectionChangeCommitted(object sender, EventArgs e)
        {
            fetchtc();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (diagid.Text == "" || diagpatid.Text == "" || diagpatname.Text == "" || diagsymp.Text == "" || diagmed.Text == "" || diadiag.Text == "" || treatid.Text == "" || diagcost.Text == "")
                MessageBox.Show("Please Fill The Empty Fields!");
            else
            {
                con.Open();
                string query = "insert into DiagnosisTable values(" + diagid.Text + ",'" + diagpatid.Text + "','" + diagpatname.Text + "','" + diagsymp.Text + "','" + diagmed.Text + "','" + diadiag.Text + "','" + treatid.Text + "','" + (int.Parse(diagcost.Text) + 500).ToString() + "')";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Diagnosis Added Successfully! \nTotal Amount Including Consultation Charges (500 PKR) : " + (int.Parse(diagcost.Text) + 500).ToString());
                con.Close();
                populate();
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (diagid.Text == "")
                MessageBox.Show("Enter The Diagnosis Id!");
            else
            {
                con.Open();
                string query = "delete from DiagnosisTable where diagnosisId=" + diagid.Text + "";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Diagnosis Successfully Deleted!");
                con.Close();
                populate();

            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (diagid.Text == "" || diagpatid.Text == "" || diagpatname.Text == "" || diagsymp.Text == "" || diagmed.Text == "" || diadiag.Text == "" || treatid.Text == "" || diagcost.Text == "")
            { MessageBox.Show("Incomplete Information!"); }
            else
            {
                con.Open();
                string query = " update DiagnosisTable set PatientId = '" + diagpatid.Text + "', PatientName = '" + diagpatname.Text + "',Symptoms = '" + diagsymp.Text + "',Medicines='" + diagmed.Text + "',Diagnosis='" + diadiag.Text + "',Treatment='" + treatid.Text + "',Cost='" + (int.Parse(diagcost.Text) + 500).ToString() + "' where DiagnosisId = " + diagid.Text + "";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Diagnosis Updated Successfully!");
                con.Close();
                populate();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.Show();
            this.Hide();        }
    }
}

