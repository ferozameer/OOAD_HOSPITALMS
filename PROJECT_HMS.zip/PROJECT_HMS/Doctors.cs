﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace DBMS_PROJECT_HMS
{
    public partial class Doctors : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Admin\Documents\HMS.mdf;Integrated Security=True;Connect Timeout=30");
        public Doctors()
        {
            InitializeComponent();
        }

        private void Doctors_Load(object sender, EventArgs e)
        {
            populate();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (did.Text == "" ||  dname.Text == "" || textBox3.Text == "" || dgen.Text == "" || dspec.Text == "" || dpass.Text=="")
                MessageBox.Show("Please Fill The Empty Fields!");
            else
            {
                con.Open();
                string query = "insert into DocTable values(" + did.Text + ",'" + dname.Text + "','" + textBox3.Text + "','" + dgen.Text + "','" + dspec.Text + "','" + dpass.Text + "')";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Doctor Successfully Added!");
                con.Close();
                populate();
            }
        }
        void populate()
        {
            con.Open();
            string query = "select * from DocTable";
            SqlDataAdapter da = new SqlDataAdapter(query, con);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            docdgv.DataSource = ds.Tables[0];
            con.Close();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (did.Text == "")
                MessageBox.Show("Enter The Doctor Id!");
            else
            {
                con.Open();
                string query = "delete from DocTable where DoctorId=" + did.Text + "";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Doctor Successfully Deleted!");
                con.Close();
                populate();

            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (did.Text == "" || dname.Text == "" || textBox3.Text == "" || dgen.Text == "" || dspec.Text == ""|| dpass.Text=="")
            { MessageBox.Show("Incomplete Information!"); }
            else
            {
                con.Open();
                string query = " update DocTable set DoctorName = '" + dname.Text + "',Experience = '" + textBox3.Text + "',Gender = '" + dgen.Text + "',specialization='" + dspec.Text + "',password='" + dpass.Text + "' where DoctorId = " + did.Text + "";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Doctor Updated Successfully!");
                con.Close();
                populate();
            }
        }


        private void label12_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void docdgv_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {

            did.Text = docdgv.Rows[e.RowIndex].Cells[0].Value.ToString();
            dname.Text = docdgv.Rows[e.RowIndex].Cells[1].Value.ToString();
            textBox3.Text = docdgv.Rows[e.RowIndex].Cells[2].Value.ToString();
            dgen.Text = docdgv.Rows[e.RowIndex].Cells[3].Value.ToString();
            dspec.Text = docdgv.Rows[e.RowIndex].Cells[4].Value.ToString();
            dpass.Text = docdgv.Rows[e.RowIndex].Cells[5].Value.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            patients p = new patients();
            p.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            receptionist r = new receptionist();
            r.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            treatments t = new treatments();
            t.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.Show();
            this.Hide();
        }
    }
    }

