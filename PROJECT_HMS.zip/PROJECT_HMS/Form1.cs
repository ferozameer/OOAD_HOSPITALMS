﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace DBMS_PROJECT_HMS
{
    public partial class Form1 : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Admin\Documents\HMS.mdf;Integrated Security=True;Connect Timeout=30");
        SqlCommand cmd = new SqlCommand();
        public Form1()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {

            if ( comboBox1.SelectedItem.ToString()=="Receptionist")
            {
                logrecep();
            }
            else if(comboBox1.SelectedItem.ToString()=="Doctor")
            {
                logdoc();
            }
        }
        private void logrecep()
        {
            if (textBox1.Text == "")
            { MessageBox.Show("Enter The Receptionist Name!"); }
            else if (textBox2.Text == "")
            { MessageBox.Show("Enter The Password!"); }
            else
            {
                con.Open();
                string query = " select * from ReceptionistTable where ReceptionistName= '" + textBox1.Text + "' and Password = '" + textBox2.Text + "'";
                cmd = new SqlCommand(query, con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                int a;
                a = ds.Tables[0].Rows.Count;
                if (a == 0)
                {
                    MessageBox.Show("Wrong Username Or Password!");
                }
                else
                {
                    patients p = new patients();
                    p.Show();
                    this.Hide();

                }
                con.Close();
            }

        }

        private void logdoc()
        {
            if (textBox1.Text == "")
            { MessageBox.Show("Enter The Doctor Name!"); }
            else if (textBox2.Text == "")
            { MessageBox.Show("Enter The Password!"); }
            else
            {
                con.Open();
                string query = " select * from DocTable where DoctorName= '" + textBox1.Text + "' and Password = '" + textBox2.Text + "'";
                cmd = new SqlCommand(query, con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                int a;
                a = ds.Tables[0].Rows.Count;
                if (a == 0)
                {
                    MessageBox.Show("Wrong Username Or Password!");
                }
                else
                {
                    diagnosis d = new diagnosis();
                    d.Show();
                    this.Hide();

                }
                con.Close();
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
        }
        private void label6_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
